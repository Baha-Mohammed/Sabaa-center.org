<?php if ( !defined( 'ABSPATH' ) ) exit(); ?>

<?php the_post_thumbnail(); ?>
