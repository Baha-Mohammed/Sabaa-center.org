<?php

// Widgets
require_once( OVA_PLUGIN_PATH.'/widgets/give-category-widget.php' );
require_once( OVA_PLUGIN_PATH.'/widgets/give-recent-widget.php' );